<?php
    session_start();    
    include_once("conectBDAdaTech.php"); 
       
    if((isset($_POST['email'])) && (isset($_POST['senha']))){
        $usuario = mysqli_real_escape_string($conexao, $_POST['email']);
        $senha = mysqli_real_escape_string($conexao, $_POST['senha']);
            
        $result_usuario = "SELECT * FROM usuario WHERE email = '$usuario' && senha = '$senha' LIMIT 1";
        $resultado_usuario = mysqli_query($conexao, $result_usuario);
        $resultado = mysqli_fetch_assoc($resultado_usuario);
        
        if(isset($resultado)){
            $_SESSION['id_usuario'] = $resultado['id_usuario'];
            $_SESSION['nome'] = $resultado['nome'];
            $_SESSION['nvlacs'] = $resultado['nvlacs'];
            $_SESSION['senha'] = $resultado['email'];
            $_SESSION['senha'] = $resultado['senha'];
            if($_SESSION['nvlacs'] == "1"){
                header("Location: PerfilADM.php");
            }elseif($_SESSION['nvlacs'] == "2"){
                header("Location: PerfilPremium.php");
            }else{
                header("Location: Perfil.php");
            }

        }else{    
            echo "<div class=\"Titulo-2\">Falha ao logar! E-mail ou senha incorretos</div>";
        }
    }else{
        echo "<div class=\"Titulo-2\"></div>";
    }
?>