<?php

include('ProtecaoAdaTech.php');

include('conectBDAdaTech.php');

$id_usuarioa = $_SESSION['id_usuario'];
$bloqueio = mysqli_fetch_assoc(mysqli_query($conexao, "SELECT * FROM bloqueio WHERE id_usuario='$id_usuarioa'"));

	if(isset($_POST['Concluir1'])){

        $result = mysqli_query($conexao, "UPDATE bloqueio SET constantes=1 WHERE id_usuario='$id_usuarioa';");

    header('Location: Ada_Lovelace_Algoritmos.php');
    die();
		
	}
    if(isset($_POST['Concluir2'])){

        $result = mysqli_query($conexao, "UPDATE bloqueio SET variaveis=1 WHERE id_usuario='$id_usuarioa';");

    header('Location: Grace_Hopper_Constantes.php');
    die();
    
    }
    if(isset($_POST['Concluir3'])){
	
        $result = mysqli_query($conexao, "UPDATE bloqueio SET entradaesaida=1 WHERE id_usuario='$id_usuarioa';");

    header('Location: Carol_Shaw_Variáveis.php');
    die();
    
    }
    if(isset($_POST['Concluir4'])){

        $id_usuarioa = $_SESSION['id_usuario'];
	
        $result = mysqli_query($conexao, "UPDATE bloqueio SET tiposdedados=1 WHERE id_usuario='$id_usuarioa';");

    header('Location: Roberta_Williams_Entrada_e_Saída.php');
    die();
    
    }
    if(isset($_POST['Concluir5'])){

        $id_usuarioa = $_SESSION['id_usuario'];
	
        $result = mysqli_query($conexao, "UPDATE bloqueio SET operadores=1 WHERE id_usuario='$id_usuarioa';");
    
        header('Location: #');
    die();
    
    }
    if(isset($_POST['Concluir6'])){

        $id_usuarioa = $_SESSION['id_usuario'];
	
        $result = mysqli_query($conexao, "UPDATE bloqueio SET funcoesmat=1 WHERE id_usuario='$id_usuarioa';");

        header('Location: #');
    die();
    
    }
    if(isset($_POST['concluir7'])){

        $id_usuarioa = $_SESSION['id_usuario'];
	
        $result = mysqli_query($conexao, "UPDATE bloqueio SET condicionais=1 WHERE id_usuario='$id_usuarioa';");

        header('Location: #');
    die();
    
    }
    if(isset($_POST['concluir8'])){

        $id_usuarioa = $_SESSION['id_usuario'];
	
        $result = mysqli_query($conexao, "UPDATE bloqueio SET expressoeslog=1 WHERE id_usuario='$id_usuarioa';");

    header('Location: #');
    die();
    
    }	
    if(isset($_POST['concluir9'])){

    header('Location: #');
    die();
    
    }	
?>