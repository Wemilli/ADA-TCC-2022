const btn = document.querySelectorAll("[draggable='true']");
const Atividade = document.querySelector(".Atividade");

function comecarArrastar(){
		console.log("Começou a arrastar");
	
	this.classList.add("Arrastando");
}

function entrouSoltar(){
	this.classList.add("hover")
	
	const elementoArrastado = document.querySelector(".arrastando");
	
	this.appendChild(elementoArrastado);
}

btn.forEach((Atividade)=>{
	Atividade.addEventListener("dragstart" , comecarArrastar);
})
		
Atividade.addEventListener("dragover", entrouSoltar);
