<?php
	include('ProtecaoAdaTech.php');

	include('conectBDAdaTech.php');

	if(isset($_POST['Salvar'])){

			$id_usuarioa = $_SESSION['id_usuario'];
			$nomea = $_POST['nome'];
			$emaila = $_POST['email'];
	
			$update = mysqli_query($conexao, "UPDATE usuario SET nome='$nomea', email='$emaila' where id_usuario='$id_usuarioa';");

			$sql = mysqli_query($conexao,$update);
		
	}
	header('Location: Perfil.php');
	die();
?>