ScrollReveal().reveal('.Tela1', { delay: 500 });
ScrollReveal().reveal('.Titulo', { delay: 1000 });
ScrollReveal().reveal('.Subtitulo', { delay: 1500 });
ScrollReveal().reveal('.Se_Inscrever', { delay: 2000 });
ScrollReveal().reveal('.Tenho_Conta', { delay: 2500 });

ScrollReveal().reveal('.Tela2', { delay: 500 });
ScrollReveal().reveal('.Texto', { delay: 1000 });
ScrollReveal().reveal('.TextoParticipacao', { delay: 1500 });

ScrollReveal().reveal('.Tela3', { delay: 500 });
ScrollReveal().reveal('img.ImgDidatica', { delay: 1000 });

ScrollReveal().reveal('.Tela4', { delay: 500 });
ScrollReveal().reveal('.TituloTela4', { delay: 1000 });
ScrollReveal().reveal('img.Equipe', { delay: 1500 });

ScrollReveal().reveal('.Rodape', { delay: 1000 });
ScrollReveal().reveal('.Copyright', { delay: 1000 });