<?php
	include('ProtecaoAdaTech.php');

	include('conectBDAdaTech.php');

	if(isset($_POST['Salvar'])){

            $id = $_GET["id"];
			$nomea = $_POST['nome'];
			$sexoa = $_POST['sexo'];
            $datanasca = $_POST['datanasc'];
			$nvlacsa = $_POST['nvlacs'];
            $nomea = $_POST['nome'];
			$emaila = $_POST['email'];
	
			$update = mysqli_query($conexao, "UPDATE usuario SET nome='$nomea', email='$emaila', datanasc='$datanasca', sexo='$sexoa', nvlacs='$nvlacsa' where id_usuario='$id';");

			$sql = mysqli_query($conexao,$update);
		
	}
	header('Location: PagADMAdaTech.php');
	die();
?>