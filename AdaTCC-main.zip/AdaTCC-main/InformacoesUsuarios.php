<?php

include('conectBDAdaTech.php');

	if (isset($_POST['nome'])){

			$nomea = $_POST['nome'];
			$datanasca = $_POST['datanasc'];
			$sexoa = $_POST['sexo'];
            $emaila = $_POST['email'];
			$senhaa = $_POST['senha'];
			$termduso = $_POST['termduso'];
	
			$result = mysqli_query($conexao, "INSERT INTO usuario(nome,datanasc,sexo,email,nvlacs,senha,image,termduso) 
			VALUES ('$nomea','$datanasca','$sexoa','$emaila','3','$senhaa','Perfil.png','$termduso')");

			$bloqueio = mysqli_query($conexao, "INSERT INTO bloqueio(algoritmo) 
			VALUES (1)");
		
	}
	header('Location: Cadastrado.php');
	die();

?>