<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" type="text/css" href="CSS.css">
    <title>AdaTech</title>
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Sofia">
    <link href="https://fonts.googleapis.com/css2?family=Advent+Pro:wght@300&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap" rel="stylesheet">
</head>
<body>
    <header>
        <nav class="nav-bar">
            <img class="Logo" src="Imagens/Logo ADA-PNG.png">
            <div class="nav-list">
                <ul>
                <li class="nav-item"><a href="PagADMAdaTech.php" class="nav-link">Controle</a></li>
                <li class="nav-item"><a href="PerfilADM.php" class="nav-link">Perfil</a></li>
                </ul>
            </div>
            <div class="mobile-menu-icon">
                <button onclick="menuShow()"><img class="icon" src="Imagens/menu_white_36dp.svg" alt=""></button>
            </div>
        </nav>
        <div class="mobile-menu">
            <ul>
                <li class="nav-item"><a href="PagADMAdaTech.php" class="nav-link">Controle</a></li>
                <li class="nav-item"><a href="PerfilADM.php" class="nav-link">Perfil</a></li>
            </ul>
        </div>
    </header>
    <script src="Menu.js"></script>

<body>
    <center>
    <br>
            <br>
    <center><img class="Logo" src="Imagens/Logo ADA-PNG.png"></center>
    <br>
        <br>
        <br>
        <h6>Informações Principais</h6>
        <br>
        <br>
        <table class="tabela"> 
            <thead>
                <tr>
                    <td width="80" align="center">
                        <h3>ID Usuário</h3>
                    </td>
                    <td width="250" align="center">
                        <h3>E-Mail</h3>
                    </td>
                    <td width="100" align="center">
                        <h3>Nivel de Acesso</h3>
                    </td>
                    <td width="100" align="center">
                        <h3>Senha</h3>
                    </td>
                    <td width="75" align="center"><img src="Imagens/alterar.png" alt="Alteração" width="40" height="40"></td>
                    <td width="75" align="center"><img src="Imagens/excluir.png" alt="Exclusão" width="40" height="40"></td>
                </tr>
            </thead>
            <tbody>
                <?php

                include('ProtecaoAdaTech.php');

                require 'conectBDAdaTech.php';

                if (!$conexao) {
                    echo "Error: Falha ao conectar-se com o banco de dados MySQL." . PHP_EOL;
                    echo "Debugging errno: " . mysqli_connect_errno() . PHP_EOL;
                    echo "Debugging error: " . mysqli_connect_error() . PHP_EOL;
                    exit;
                }
                //query SQL
                $sql = "SELECT * FROM usuario";
                $rs = mysqli_query($conexao, $sql);
                echo "<h4>";
                while ($dado = mysqli_fetch_assoc($rs)) {
                    // Exibe na tela os dados dos contatos da tabelapessoa
                ?>
                    <tr>
                        <td height="30" align="center"><h4><?php echo $dado['id_usuario'] ?></h4></td>
                        <td align="center"><h5><?php echo $dado['email'] ?></h5></td>
                        <td align="center"><h5><?php echo $dado['nvlacs'] ?></h5></td>
                        <td align="center"><h7 class="senha"><?php echo $dado['senha'] ?></h7></td>
                        <td align="center"><?php echo "<a href='EditarPerfilADM.php?id=" . $dado['id_usuario'] . "'><button class='Editar' type='submit'><h1>Alterar</button></a>" ?></td>
                        <td align="center"><?php echo "<a href='ExclusãoAdaTech.php?id=" . $dado['id_usuario'] . "'><button class='Excluir' type='submit'><h1>Deletar</button></a>" ?></td>
                    </tr>
                <?php
                }
                // Encerra a conexão mysqli_close($link);
                ?>
            </tbody>
        </table>
        <br>
        <br>
        <h6>Informações Adicionais</h6>
        <br>
        <br>
        <table class="tabela"> 
            <thead>
                <tr>
                    <td width="80" align="center">
                        <h3>ID Usuário</h3>
                    </td>
                    <td width="160" height="60" align="center">
                        <h3>Foto de Perfil</h3>
                    </td>
                    <td width="250" align="center">
                        <h3>Nome</h3>
                    </td>
                    <td width="100" align="center">
                        <h3>Gênero</h3>
                    </td>
                    <td width="150" align="center">
                        <h3>Data de Nascimento</h3>
                    </td>
                    <td width="75" align="center"><img src="Imagens/alterar.png" alt="Alteração" width="40" height="40"></td>
                    <td width="75" align="center"><img src="Imagens/excluir.png" alt="Exclusão" width="40" height="40"></td>
                </tr>
            </thead>
            <tbody>
                <?php

                include('ProtecaoAdaTech.php');

                require 'conectBDAdaTech.php';

                if (!$conexao) {
                    echo "Error: Falha ao conectar-se com o banco de dados MySQL." . PHP_EOL;
                    echo "Debugging errno: " . mysqli_connect_errno() . PHP_EOL;
                    echo "Debugging error: " . mysqli_connect_error() . PHP_EOL;
                    exit;
                }
                //query SQL
                $sql = "SELECT * FROM usuario";
                $rs = mysqli_query($conexao, $sql);
                echo "<h4>";
                while ($dado = mysqli_fetch_assoc($rs)) {
                    // Exibe na tela os dados dos contatos da tabelapessoa
                ?>
                    <tr>
                        <td height="30" align="center"><h4><?php echo $dado['id_usuario'] ?></h4></td>
                        <td height="160" align="center"><?php echo '<img class="Perfil" src="'.'/Perfil/'.$dado['image'].'"/>' ?></td>
                        <td align="center"><h5><?php echo $dado['nome'] ?></h5></td>
                        <td align="center"><h5><?php echo $dado['sexo'] ?></h5></td>
                        <td align="center"><h5><?php echo $dado['datanasc'] ?></h5></td>
                        <td align="center"><?php echo "<a href='EditarPerfilADM.php'><button class='Editar' type='submit'><h1>Alterar</button></a>" ?></td>
                        <td align="center"><?php echo "<a href='ExclusãoAdaTech.php'><button class='Excluir' type='submit'><h1>Deletar</button></a>" ?></td>
                    </tr>
                <?php
                }
                // Encerra a conexão mysqli_close($link);
                ?>
            </tbody>
        </table>
        <br>
            <br>
            <p><a href='http://localhost/Cadastrar.php'><h5>Cadastrar Novo Usuário?</a>
            <br>
            <br>
            </p>
        </h2>
    </center>
    <footer class="Rodape">
                    <img class="Logo_rodape" src="Imagens/Logo ADA-PNG.png"></a>
                    <div class="Espacamento">
                        <div class="Contato"><h2>Contatos</h2></div>
                        <div id="Contatinhos">
                            <a href="https://instagram.com/ada_.tech?igshid=Zjc2ZTc4Nzk= "><div id="Alinhar_imagem"><img class="Foto_Contato" src="Imagens/instagram.png"></a>ada_.tech</div>
                            <div id="Alinhar_imagem"><img class="Foto_Contato" src="Imagens/email.png">adatcc2022@gmail.com</div>
                        </div>
                    </div>
                    <a href="http://localhost/termosdeuso.html"><button class="Termos" type="submit">Termos de Uso</button></a>
                    <a href="http://forms.gle/vroVG1DZytyFwpQU7.html"><button class="Ajuda" type="submit">Central de Ajuda</button></a>
                </footer>
                <div class="Copyright"> ©2022 Copyright - AdaTech</div>
            </body>
        </html>