let perguntas = [
     {
        subtitulo:'',
        titulo: 'Você chegou ao fim!',
        alternativas:[],
        correta:0
    },
{
    subtitulo:'Selecione a alternativa correta:',
    titulo: ' A lógica de programação consiste na organização de raciocínio. Funciona como uma receita de bolo porque:',
    alternativas:['Está sempre relacionada a deliciosos bolos.','Tem vies culinário na sua prototipagem.','Dispoe de maneira lógica os passos a serem seguidos.'],
    correta: 2
},
{
    subtitulo:'Selecione a alternativa correta:',
    titulo: 'Assinale a alternativa que representa a utilização de Algoritmos no cotidiano.',
    alternativas:['Jogos De Futebol.','Receitas Culinárias.','Histórias De Terror.'],
    correta: 1
},
{
    subtitulo:'Selecione a alternativa correta:',
    titulo: 'São componentes essênciais para a criação de um Algoritmo na programação. ',
    alternativas:[' Circuitos Eletrónicos',' Materiais De Plastico, Vidro E Borracha.',' Variáveis, Constantes E Funções Lógicas'],
    correta: 2
},

{
    subtitulo:'Selecione a alternativa correta:',
    titulo: 'Considere a afirmação a seguir:“método de organização de raciocínio com o propósito de estruturar a execução de ações, com o fim de sistematizar onde se iniciam, sesucedem e se encerram.” A afirmação acima refere-se a:',
    alternativas:['Algoritmos.','Variáveis.',' Constantes.'],
    correta: 0
},

]

let app = {
    start: function(){
    
        this.Atualpos = 1;
        this.Totalpontos = 0;
    
        let alts = document.querySelectorAll('.alternativa');
        alts.forEach((element,index)=>{
            element.addEventListener('click', ()=>{
                this.checaResposta(index);
            })
        })
        this.atualizaPontos();
        app.mostraquestao(perguntas[this.Atualpos]);
    },
    
    mostraquestao: function(q){
        this.qatual = q;
         // mostrando o subtitulo
         let subtitleDiv = document.getElementById('subtitulo');
         subtitleDiv.textContent = q.subtitulo;
        // mostrando o titulo
        let titleDiv = document.getElementById('titulo');
        titleDiv.textContent = q.titulo;
        // mostrando as alternativas
        let alts = document.querySelectorAll('.alternativa');
        alts.forEach(function(element,index){
            element.textContent = q.alternativas[index];
        })
    
    },
    
    Proximaperg: function(){
        this.Atualpos++;
        if(this.Atualpos == perguntas.length){
            this.Atualpos = 0;
        }
    },
    
    checaResposta: function(user){
        if(this.qatual.correta == user){
            console.log("Correta")
            this.Totalpontos++;
            this.mostraresposta(true);
        }
        else{
            console.log("Errada")
            this.mostraresposta(false);
        }
        this.atualizaPontos();
        this.Proximaperg();
        this.mostraquestao(perguntas[this.Atualpos]);
    },
    
    atualizaPontos: function(){
        let scoreDiv = document.getElementById('pontos');
        scoreDiv.textContent = `Sua pontuacao: ${this.Totalpontos}`;
    },
    
    mostraresposta: function (correto) {
        let resultDiv = document.getElementById('result');
        let result = '';
        // formate a mensagem a ser exibida
        if (correto) {
          result = 'Resposta Correta!';
        }
        else {
          // obtenha a questão atual
          let pergunta = perguntas[this.Atualpos];
          // obtenha o índice da resposta correta da questão atual
          let cindice = pergunta.correta;
          // obtenha o texto da resposta correta da questão atual
          let ctexto = pergunta.alternativas[cindice];
          result = `Incorreto! Resposta Correta: ${ctexto}`;
        }
        resultDiv.textContent = result;
      }
    
    
    }

    app.start();

    function goBack(){
        window.history.back();
    }