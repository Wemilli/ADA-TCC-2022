<?php

include('ProtecaoAdaTech.php');

require 'conectBDAdaTech.php';

$sessionId = $_GET["id"];
$user = mysqli_fetch_assoc(mysqli_query($conexao, "SELECT * FROM usuario WHERE id_usuario = $sessionId"));
?>
<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" type="text/css" href="protecao.css">
    <title>AdaTech</title>
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Sofia">
    <link href="https://fonts.googleapis.com/css2?family=Advent+Pro:wght@300&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap" rel="stylesheet">
</head>

<body>
    <?php

     
    $id = $_GET["id"];

    echo "<div class='Tela1'>
    <br> <br>
    <p class='Texto'><label class='Textooperadores'><b>Tem Certeza? </b><br></label><label class='Texto'>
    Uma vez que o usuário </label><label class='TextoVerde'><b>".$user['nome']."</b><br></label>
    <label class='Textoalgoritmo'><b>Essa ação será irreversível</p>
    <br> 
    <a href='http://localhost/ExclusãodeUsuario.php?id=$id'><button class='Retornar'>Confirmar</button></a>
    <br> <br>
    <a href='http://localhost/Gelato/usuarios.php'><button class='Cancela'>Cancelar</button></a>
    <br> <br>
</div>";
    ?>
</body>
</html>