<?php
    $id = $_GET["id"];
    // Conectar com o Banco de Dados
    include('ProtecaoAdaTech.php');

    require 'conectBDAdaTech.php';


    //query SQL
    $sql = "DELETE FROM usuario WHERE id_usuario = $id";
    $sql2 = "DELETE FROM bloqueio WHERE id_usuario = $id";
    $rs = mysqli_query($conexao, $sql);
    $rs2 = mysqli_query($conexao, $sql2);

	header('Location: PagADMAdaTech.php');
	die();
    ?>