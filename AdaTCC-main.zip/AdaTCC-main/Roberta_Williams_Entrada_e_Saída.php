<?php

include('ProtecaoAdaTech.php');

require 'conectBDAdaTech.php';

$sessionId = $_SESSION["id_usuario"];
$user = mysqli_fetch_assoc(mysqli_query($conexao, "SELECT * FROM usuario WHERE id_usuario = $sessionId"));
?>
<!DOCTYPE html>
<html>
	<head>
		<meta charset="UTF-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="viewport" content="width=device-width,
		initial-scale=1.0">
		<title>AdaTech</title>
		<link rel="stylesheet" type="text/css" href="Roberta_Williams_Entrada_e_Saída.css">
		<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Sofia">
    <link href="https://fonts.googleapis.com/css2?family=Advent+Pro:wght@300&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap" rel="stylesheet">
	</head>
        <body>
            <section>
            <div class="book">
                <div class="back"></div>
                <div class="page6"> <br><a href="https://drive.google.com/file/d/1KUH2S7OBq5kCkF2yTYAcMEtlnQvaRyth/view?usp=drivesdk"><button class="Botão-1">Acessar história</button></a>
                    <br><a href="https://drive.google.com/file/d/1TfSkSALAdjPpSnSuIvdH0FkiGO-lSnRT/view?usp=drivesdk"><button class="Botão-2">Acessar Mapa Mental</button></a></div>
                <div class="page5"><img class="ada-book" id="inverter" src="Imagens/robertawilliams.png"></div>
                <div class="page4"></div>
                <div class="page3"></div>
                <div class="page2"></div>
                <div class="page1"></div>
                <div class="front"><br><img class="algoritmo" src="imagens/entradaesaida1.png"><br><br><br><br><h1>ENTRADA E SAÍDA</h1></div>
              </div>
            </section> 
  
    </body>
    </html>