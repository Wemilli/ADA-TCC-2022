let perguntas = [
    {
       subtitulo:'',
       titulo: 'Você chegou ao fim!',
       alternativas:[],
       correta:0
   },
{
    subtitulo:'Selecione a alternativa Correta:',
    titulo: ' Na programação, é correto afirmar que: ',
    alternativas:['Uma Constante armazena um valor variável.',' Uma Constante armazena um valor fixo.','Constantes não tem propriedades de armazenamento.'],
    correta: 1
 },
 {
    subtitulo:'Selecione a alternativa Correta:',
    titulo: ' Uma Constante deve ser utilizada quando no decorrer da execução do Algoritmo:',
    alternativas:['Uma informação não séra alterada','Uma informação tem pouca probabilidade de ser alterada.',' Uma informação tem muita probabilidade de ser alterada.'],
    correta: 0
 },
 {
    subtitulo:'Selecione a alternativa Correta:',
    titulo: 'Assinale a alternativa que representa um tipo de constante:',
    alternativas:['Constante de Compatibilidade.','Constante de Variação.','Constante Literal.'],
    correta: 2
 },
 
 {
     subtitulo:'Selecione a alternativa Correta:',
     titulo: 'É Correto afirmar como um valor Constante:',
     alternativas:['Preço da torta de limão da padaria.','Altura de crianças de 10 a 13 anos.','Velocidade da luz.'],
     correta: 2
 
 },
]

let app = {
    start: function(){
    
        this.Atualpos = 1;
        this.Totalpontos = 0;
    
        let alts = document.querySelectorAll('.alternativa');
        alts.forEach((element,index)=>{
            element.addEventListener('click', ()=>{
                this.checaResposta(index);
            })
        })
        this.atualizaPontos();
        app.mostraquestao(perguntas[this.Atualpos]);
    },
    
    mostraquestao: function(q){
        this.qatual = q;
         // mostrando o subtitulo
         let subtitleDiv = document.getElementById('subtitulo');
         subtitleDiv.textContent = q.subtitulo;
        // mostrando o titulo
        let titleDiv = document.getElementById('titulo');
        titleDiv.textContent = q.titulo;
        // mostrando as alternativas
        let alts = document.querySelectorAll('.alternativa');
        alts.forEach(function(element,index){
            element.textContent = q.alternativas[index];
        })
    
    },
    
    Proximaperg: function(){
        this.Atualpos++;
        if(this.Atualpos == perguntas.length){
            this.Atualpos = 0;
        }
    },
    
    checaResposta: function(user){
        if(this.qatual.correta == user){
            console.log("Correta")
            this.Totalpontos++;
            this.mostraresposta(true);
        }
        else{
            console.log("Errada")
            this.mostraresposta(false);
        }
        this.atualizaPontos();
        this.Proximaperg();
        this.mostraquestao(perguntas[this.Atualpos]);
    },
    
    atualizaPontos: function(){
        let scoreDiv = document.getElementById('pontos');
        scoreDiv.textContent = `Sua pontuacao: ${this.Totalpontos}`;
    },
    
    mostraresposta: function (correto) {
        let resultDiv = document.getElementById('result');
        let result = '';
        // formate a mensagem a ser exibida
        if (correto) {
          result = 'Resposta Correta!';
        }
        else {
          // obtenha a questão atual
          let pergunta = perguntas[this.Atualpos];
          // obtenha o índice da resposta correta da questão atual
          let cindice = pergunta.correta;
          // obtenha o texto da resposta correta da questão atual
          let ctexto = pergunta.alternativas[cindice];
          result = `Incorreto! Resposta Correta: ${ctexto}`;
        }
        resultDiv.textContent = result;
      }
    
    
    }

    
    
    app.start();
   
    function goBack(){
        window.history.back();
    } 
