<?php

if(!isset($_SESSION)){
    session_start();
}

$nomea = $_SESSION['nome'];
$datanasca = $_SESSION['datanasc'];
$sexoa = $_SESSION['sexo'];
$emaila = $_SESSION['email'];
$senhaa = $_SESSION['senha'];

unset($nomea);
unset($datanasca);
unset($sexoa);
unset($emaila);
unset($senhaa);

session_destroy();

header("Location: HomeVisitante.html");
?>