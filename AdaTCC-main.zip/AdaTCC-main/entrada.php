<?php

include('ProtecaoAdaTech.php');

require 'conectBDAdaTech.php';

$sessionId = $_SESSION["id_usuario"];
$user = mysqli_fetch_assoc(mysqli_query($conexao, "SELECT * FROM usuario WHERE id_usuario = $sessionId"));
?>
<!DOCTYPE html>
<html lang="pt-br">

    <head>
		<meta charset="UTF-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<title>AdaTech</title>
		<link rel="stylesheet" type="text/css" href="entrada.css">
		<script src="https://unpkg.com/scrollreveal"></script>
		<link href="https://fonts.googleapis.com/css2?family=Advent+Pro:wght@300&display=swap" rel="stylesheet">
		<link href="https://fonts.googleapis.com/css2?family=Poppins:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap" rel="stylesheet">
</head>
	<body>
    <header>
      <nav class="nav-bar">
          <img class="Logo" src="Imagens/Logo ADA-PNG.png">
          <div class="nav-list">
              <ul>
                <li class="nav-item"><a href="Home.php" class="nav-link">Home</a></li>
                <li class="nav-item"><a href="Modulos.php" class="nav-link">Módulos</a></li>
                <li class="nav-item"><a href="Biblioteca.php" class="nav-link">Biblioteca</a></li>
                <li class="nav-item"><a href="Perfil.php" class="nav-link">Perfil</a></li>
              </ul>
          </div>
          <div class="mobile-menu-icon">
              <button onclick="menuShow()"><img class="icon" src="Imagens/menu_white_36dp.svg" alt=""></button>
          </div>
      </nav>
      <div class="mobile-menu">
          <ul>
            <li class="nav-item"><a href="Home.php" class="nav-link">Home</a></li>
            <li class="nav-item"><a href="Modulos.php" class="nav-link">Módulos</a></li>
            <li class="nav-item"><a href="Biblioteca.php" class="nav-link">Biblioteca</a></li>
            <li class="nav-item"><a href="Perfil.php" class="nav-link">Perfil</a></li>
          </ul>
      </div>
  </header>
  <script src="Menu.js"></script>

		</div>

        <button onclick="goBack()" class="botao-voltar"><img class="Voltar" src="Imagens/entrada.png"></button>
				<div class="Tela">
        

            <section>
                <div class="Algoritmo">ENTRADA E SAÍDA</div>
                <p>
                    Agora, vamos tratar dos conteúdos dentro de uma pseudo linguagem de programação.<br />
                    <br />
                    Qual linguagem vamos usar nesse primeiro momento? <br />
                    <br />
                    G-Portugol, é um dialeto da linguagem/pseudocódigo portugol (ou portugês estruturado), 
                    muito usada para descrever algoritmos em português, de forma livre e espontânea.</br>
                </p>
                <p>Todo algoritmo necessita de uma forma de obtenção dos dados de entrada do problema, assim 
                    como uma forma de comunicação da saída por ele produzida. Para tal, os algoritmos contam 
                    com instruções de entrada e saída. Na linguagem Portugol, a instrução de leitura é leia e 
                    a instrução de saída é escreva.  A instrução de leitura requer o nome de uma variável para 
                    armazenar o dado de entrada a ser obtido.<br />
                    <br>
                    Por exemplo, leia( lado ) <br />
                    onde o lado é o nome de uma variável. Quando a instrução acima é executada, o valor lido passa
                     a ser o conteúdo de lado. Logo, para acessar o valor lido, basta usarmos o nome da variável. 
                     É importante lembrar que a variável tem de ser declarada antes de seu uso pela instrução de 
                     leitura. A instrução de escrita, na linguagem Portugol, é denominada escreva. Esta instrução 
                     também requer um argumento, que corresponde ao valor a ser escrito como saída. Este valor pode
                    ser o conteúdo de uma variável ou uma constante do tipo inteiro, real ou caractere.<br />
                    <br>
                    Por exemplo, escreva( lado )<br />
                    escreve como saída o valor da variável de nome lado. <br />
                    É interessante frisar que a instrução de escrita não é usada apenas para escrever o resultado do algoritmo,
                    mas sim para escrever qualquer informação que auxilie a comunicação entre o algoritmo e o “mundo exterior”. 
                    Por exemplo, é comum escrevermos uma mensagem antes de uma instrução de leitura.<br />
                    <br />
                    Esta mensagem, em geral, é uma descrição muito sucinta do valor que o algoritmo espera receber do “mundo exterior”
                    para atribuir à variável na instrução de leitura.<br />
                    <br>O uso da instrução de escrita para emitir mensagens é motivado pelo fato de um programa de computador, em geral,
                    interagir com o ser humano durante sua execução; isto é, o “mundo exterior” é, em geral, um humano. Mais especificamente,
                    é bastante comum que a entrada de um programa seja fornecida por um ser humano. Neste caso, as mensagens de saída têm 
                    como objetivo auxiliar a comunicação entre o programa e o ser humano, que é conhecido por usuário. Em um ambiente de 
                    programação típico, as mensagens de saída aparecem em um monitor de vídeo e os dados de entrada são fornecidos ao programa 
                    por meio de um teclado ou mouse.<br />

                </p>
    </div>
    </section>
    <div id="progress-bar"></div>
    <script src="entrada.js"></script>
    <div class="botao">
        <a href="videoES.html"><button class="Prossiga">Prossiga</button></a>
    </div>
    <footer class="Rodape">
                    <img class="Logo_rodape" src="Imagens/Logo ADA-PNG.png"></a>
                    <div class="Espacamento">
                        <div class="Contato"><h2>Contatos</h2></div>
                        <div id="Contatinhos">
                            <a href="https://instagram.com/ada_.tech?igshid=Zjc2ZTc4Nzk= "><div id="Alinhar_imagem"><img class="Foto_Contato" src="Imagens/instagram.png"></a>ada_.tech</div>
                            <div id="Alinhar_imagem"><img class="Foto_Contato" src="Imagens/email.png">adatcc2022@gmail.com</div>
                        </div>
                    </div>
                    <a href="http://localhost/termosdeuso.html"><button class="Termos" type="submit">Termos de Uso</button></a>
                    <a href="http://forms.gle/vroVG1DZytyFwpQU7.html"><button class="Ajuda" type="submit">Central de Ajuda</button></a>
                </footer>
                <div class="Copyright"> ©2022 Copyright - AdaTech</div>
            </body>
        </html>
