<?php
	include('ProtecaoAdaTech.php');

	include('conectBDAdaTech.php');

    if($_POST['Salvar']) {
        $senha          = $_POST['senha'];
        $senhaConfirma  = $_POST['senha_confirma'];

        if ($senha == $senhaConfirma) {
            $emaila = $_POST['email'];
			$senhaa = $_POST['senha'];
	
			$update = mysqli_query($conexao, "UPDATE usuario SET senha='$senhaa', WHERE email='$emaila';");

			$sql = mysqli_query($conexao,$update);

            $mensagem = "<span class='sucesso'>Senha Modificada com Sucesso!</span>";
        } else {
            $mensagem = "<span class='erro'>Senhas estão diferentes :(</span>";
        }
        echo "<script>alert('$mensagem');</script>";

        header('Location: Login.php');
        die();
    }
?>