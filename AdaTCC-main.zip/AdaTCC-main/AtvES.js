let perguntas = [
    {
       subtitulo:'',
       titulo: 'Você chegou ao fim!',
       alternativas:[''],
       correta:0
   },
{
   subtitulo:'Selecione a alternativa Correta:',
   titulo: '  Observe a afirmação a seguir: “Todo Algoritmo necessita de uma forma de obtenção dos Dados de Entrada do problema, assim como uma forma de Comunicação da Saída por ele produzida.” A afirmação está:',
   alternativas:[' Parcialmente Errada.','Certa.','Errada.'],
   correta: 1
},
{
   subtitulo:'Selecione a alternativa Correta:',
   titulo: 'A instrução de Escrita, na linguagem portugol, é denominada:',
   alternativas:[' Escreva.','Escrevendo.','Escrito.'],
   correta: 0
},
{
   subtitulo:'Selecione a alternativa Correta:',
   titulo: 'A instrução de Leitura, na linguagem portugol, é denominada:',
   alternativas:['Lendo',' Lido.',' Leia.'],
   correta: 2
},

{
   subtitulo:'Selecione a alternativa Correta:',
   titulo: 'Observe a afirmação a seguir e selecione a Alternativa Correta: “As mensagens de Saída têm como objetivo auxiliar a comunicação entre o programa e o ser humano, que é conhecido por usuário. em um ambiente de programação típico, as mensagens de Saída aparecem em_____________.”',
   alternativas:[' Livros de culinaria.','Rádios.',' Um monitor de vídeo, e os Dados de Entrada são fornecidos ao programa por meio de um teclado ou mouse.'],
   correta: 0
},

]

let app = {
   start: function(){
   
       this.Atualpos = 1;
       this.Totalpontos = 0;
   
       let alts = document.querySelectorAll('.alternativa');
       alts.forEach((element,index)=>{
           element.addEventListener('click', ()=>{
               this.checaResposta(index);
           })
       })
       this.atualizaPontos();
       app.mostraquestao(perguntas[this.Atualpos]);
   },
   
   mostraquestao: function(q){
       this.qatual = q;
        // mostrando o subtitulo
        let subtitleDiv = document.getElementById('subtitulo');
        subtitleDiv.textContent = q.subtitulo;
       // mostrando o titulo
       let titleDiv = document.getElementById('titulo');
       titleDiv.textContent = q.titulo;
       // mostrando as alternativas
       let alts = document.querySelectorAll('.alternativa');
       alts.forEach(function(element,index){
           element.textContent = q.alternativas[index];
       })
   
   },
   
   Proximaperg: function(){
       this.Atualpos++;
       if(this.Atualpos == perguntas.length){
           this.Atualpos = 0;
       }
   },
   
   checaResposta: function(user){
       if(this.qatual.correta == user){
           console.log("Correta")
           this.Totalpontos++;
           this.mostraresposta(true);
       }
       else{
           console.log("Errada")
           this.mostraresposta(false);
       }
       this.atualizaPontos();
       this.Proximaperg();
       this.mostraquestao(perguntas[this.Atualpos]);
   },
   
   atualizaPontos: function(){
       let scoreDiv = document.getElementById('pontos');
       scoreDiv.textContent = `Sua pontuacao: ${this.Totalpontos}`;
   },
   
   mostraresposta: function (correto) {
       let resultDiv = document.getElementById('result');
       let result = '';
       // formate a mensagem a ser exibida
       if (correto) {
         result = 'Resposta Correta!';
       }
       else {
         // obtenha a questão atual
         let pergunta = perguntas[this.Atualpos];
         // obtenha o índice da resposta correta da questão atual
         let cindice = pergunta.correta;
         // obtenha o texto da resposta correta da questão atual
         let ctexto = pergunta.alternativas[cindice];
         result = `Incorreto! Resposta Correta: ${ctexto}`;
       }
       resultDiv.textContent = result;
     }
   
   
   }

   
   
   app.start();
   
   function goBack(){
    window.history.back();
} 
