<?php

include('ProtecaoAdaTech.php');

require 'conectBDAdaTech.php';

$sessionId = $_SESSION["id_usuario"];
$user = mysqli_fetch_assoc(mysqli_query($conexao, "SELECT * FROM usuario WHERE id_usuario = $sessionId"));

$Nome = $user['nome'];
$primeiroNome = explode(" ", $Nome);
?>
<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" type="text/css" href="Home.css">
    <script src="https://unpkg.com/scrollreveal"></script>
    <title>AdaTech</title>
    <link href="https://fonts.googleapis.com/css2?family=Advent+Pro:wght@300&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap" rel="stylesheet">
</head>
<body>
<div class="Tela2">
<div class="Titulos_botoes">
    <div class="Titulo"><b>Premium</b></div>
    <br>
    <div class="Subtitulo">Quer ter acesso a Mapas Mentais, um Portal de Duvidas e todas as Histórias é Módulos Desbloqueados!?</div>
    <br> <br> 
        <button class="Se_Inscrever" type="submit">Clique Aqui!</button>
</div>
</div>
</body>
</html>