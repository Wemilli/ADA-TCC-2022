class Validator {

	constructor() {
	  this.validations = [
		'data-min-length',
		'data-max-length',
		'data-only-letters',
		'data-email-validate',
		'data-required',
	  ]
	}
  
	// inicia a validação de todos os campos
	validate(form) {
  
	  // limpa todas as validações antigas
	  let currentValidations = document.querySelectorAll('form .validacao');
  
	  if(currentValidations.length) {
		this.cleanValidations(currentValidations);
	  }
  
	  // pegar todos inputs e selects
	  let inputs = form.getElementsByTagName('input');
	  let selects = form.getElementsByTagName('select');
	  // transformar HTMLCollection em arr
	  let inputsArray = [...inputs];
	  let selectsArray = [...selects];
	  // loop nos inputs e validação mediante aos atributos encontrados
	  inputsArray.forEach(function(input, obj) {
  
		// fazer validação de acordo com o atributo do input
		for(let i = 0; this.validations.length > i; i++) {
		  if(input.getAttribute(this.validations[i]) != null) {
  
			// limpa string para saber o método
			let method = this.validations[i].replace("data-", "").replace("-", "");
  
			// valor do input
			let value = input.getAttribute(this.validations[i])
  
			// invoca o método
			this[method](input,value);
  
		  }
		}
  
	  }, this);

	  selectsArray.forEach(function(select, obj) {
  
		// fazer validação de acordo com o atributo do select
		for(let i = 0; this.validations.length > i; i++) {
		  if(select.getAttribute(this.validations[i]) != null) {
  
			// limpa string para saber o método
			let method = this.validations[i].replace("data-", "").replace("-", "");
  
			// valor do select
			let value = select.getAttribute(this.validations[i])
  
			// invoca o método
			this[method](select,value);
  
		  }
		}
  
	  }, this);
  
	}
  
	// método para validar se tem um mínimo de caracteres
	minlength(input, minValue) {
  
	  let inputLength = input.value.length;
  
	  let errorMessage = `O campo precisa ter pelo menos ${minValue} caracteres`;
  
	  if(inputLength < minValue) {
		this.printMessage(input, errorMessage);
	  }
  
	}
  
	// método para validar se passou do máximo de caracteres
	maxlength(input, maxValue) {
  
	  let inputLength = input.value.length;
  
	  let errorMessage = `O campo precisa ter menos que ${maxValue} caracteres`;
  
	  if(inputLength > maxValue) {
		this.printMessage(input, errorMessage);
	  }
  
	}
  
	// método para validar strings que só contem letras
	onlyletters(input) {
  
	  let re = /^([A-Za-zá-úâ-ûã-õ\s]){1,50}/;
  
	  let inputValue = input.value;
  
	  let errorMessage = `Este campo não aceita números nem caracteres especiais`;
  
	  if(!re.test(inputValue)) {
		this.printMessage(input, errorMessage);
	  }
  
	}
  
	// método para validar e-mail
	emailvalidate(input) {
	  let re = /\S+@gmail.com+/;
  
	  let email = input.value;
  
	  let errorMessage = `Insira um e-mail no padrão adatcc2022@gmail.com`;
  
	  if(!re.test(email)) {
		this.printMessage(input, errorMessage);
	  }
  
	}
	
	// método para exibir inputs que são necessários
	required(input) {
  
	  let inputValue = input.value;
  
	  if(inputValue === '') {
		let errorMessage = `Este campo é obrigatório`;
  
		this.printMessage(input, errorMessage);
	  }
  
	}

	// método para exibir selects que são necessários
	required(select) {
  
		let selectValue = select.value;
	
		if(selectValue === '') {
		  let errorMessage = `Este campo é obrigatório`;
	
		  this.printMessage(select, errorMessage);
		}
	
	  }
  
	// método para imprimir mensagens de erro
	printMessage(input, msg) {
	
	  // checa os erros presentes no input
	  let errorsQty = input.parentNode.querySelector('.validacao');
  
	  // imprimir erro só se não tiver erros
	  if(errorsQty === null) {
		let template = document.querySelector('.validacao').cloneNode(true);
  
		template.textContent = msg;
	
		let inputParent = input.parentNode;
	
		template.classList.remove('template');
	
		inputParent.appendChild(template);
	  }
  
	}

	printMessage(select, msg) {
	
		// checa os erros presentes no select
		let errorsQty = select.parentNode.querySelector('.validacao');
	
		// imprimir erro só se não tiver erros
		if(errorsQty === null) {
		  let template = document.querySelector('.validacao').cloneNode(true);
	
		  template.textContent = msg;
	  
		  let selectParent = select.parentNode;
	  
		  template.classList.remove('template');
	  
		  selectParent.appendChild(template);
		}
	
	  }
  
	// remove todas as validações para fazer a checagem novamente
	cleanValidations(validations) {
	  validations.forEach(el => el.remove());
	}
  
  }
  
  let form = document.getElementById('Formulario-1-1-1');
  let submit = document.getElementById('Botão');
  
  let validator = new Validator();
  
  // evento de envio do form, que valida os inputs
  submit.addEventListener('click', function(e) {
	e.preventDefault();

	validator.validate(form);

  });