<?php
	require_once 'config.php';
	require_once 'vendor/autoload.php';

	use Rafa\Adapters\PhpMailerAdapter;

	$subject = 'Bem vindo';
	//$body = '<h1>Bem vindo Fulano,</h1><p>se inscreva no canal...</p>';
	$body = file_get_contents('app/template/email/welcome.html');

	$mail = new PhpMailerAdapter;
	$mail->setFrom('adatcc2022@gmail.com', 'ADA');
	$mail->addAddress('cltais2@gmail.com', 'Tainá');
	$mail->mountContent($subject, $body);
	$mail->addAttachment('photo2.png');
	$mail->send();