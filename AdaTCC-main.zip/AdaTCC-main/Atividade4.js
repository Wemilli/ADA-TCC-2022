let pergunta = {
    Texto: ' A lógica de programação consiste na organização de raciocínio. Funciona como uma receita de bolo porque:',
    Opcao:['Está sempre relacionada a deliciosos bolos.',' Tem vies culinário na sua prototipagem.',' Dispoe de maneira lógica os passos a serem seguidos.'],
    correta: 2
};

function mostraquestao(q){
    let titleDiv = document.getElementById('Texto');
    titleDiv.textContent = q.Texto;

    let alts = document.querySelectorAll('.Opcao');
    alts.forEach(function(element,index){
        element.textContent = q.Opcao[index];
        element.addEventListener('click', function(){
            if(index == q.correta){
                console.log("Acertou!")
            }
            else{
                console.log("Errou!")
            }
        })
    })

}

mostraquestao(pergunta);