<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" type="text/css" href="Cadastrar.css">
    <title>AdaTech</title>
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Sofia">
    <link href="https://fonts.googleapis.com/css2?family=Advent+Pro:wght@300&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap" rel="stylesheet">
</head>
<body>
    <header>
        <nav class="nav-bar">
            <img class="Logo" src="Imagens/Logo ADA-PNG.png">
            <div class="nav-list">
                <ul>
                    <li class="nav-item"><a href="HomeVisitante.html" class="nav-link">Home</a></li>
                    <li class="nav-item"><a href="Premium.html" class="nav-link">Planos</a></li>
                    <li class="nav-item"><a href="Login.php" class="nav-link">Login</a></li>
                </ul>
            </div>
            <div class="mobile-menu-icon">
                <button onclick="menuShow()"><img class="icon" src="Imagens/menu_white_36dp.svg" alt=""></button>
            </div>
        </nav>
        <div class="mobile-menu">
            <ul>
                <li class="nav-item"><a href="HomeVisitante.html" class="nav-link">Home</a></li>
                <li class="nav-item"><a href="Premium.html" class="nav-link">Planos</a></li>
                <li class="nav-item"><a href="Login.php" class="nav-link">Login</a></li>
            </ul>
        </div>
    </header>
    <script src="Menu.js"></script>
    <br>
    <br>
		<div class="Botões">
        <a href="Login.php"><button class="Botão-1" type="submit">Login</button></a>
        <br>
        <a  href="Cadastrar.php"><button class="Botão-2" type="submit">Cadastrar</button></a>
		</div>
        <section class="Formulario-1">
			<div class="Formulario-1-1"><!--Problemática 1:2. Formulário refere-se ao conjunto.(Login/senha)-->
				<h1 class="Titulo-1">Cadastrar</h1>
                <br>
				<form class="Formulario-1-1-1" id="Formulario-1-1-1" action="InformacoesUsuarios.php" method="POST">
					    <input class="Input1" type="text" name="nome" id="name" placeholder="Nome do usúario:" minlength="10" maxlength="50" required>
					<br>
					<br>
					    <input class="Input" type="date" name="datanasc" placeholder="Data de nascimento:" required>
					<br>
					<br>
                        <select class="Input-3" name="sexo" required>
                            <option value="" disabled selected>Gênero:</option>
                            <option value="Masculino">Masculino</option>
                            <option value="Feminino">Feminino</option>
                            <option value="Outro">Outro</option>
                        </select>
					<br>
					<br>
					    <input class="Input3" type="email" name="email" placeholder="Insira seu e-mail:" pattern=".+@gmail\.com" size="50" required>
                        <script>
                            document.querySelector('input[type=email]').oninvalid = function() {

                            // remove mensagens de erro antigas
                            this.setCustomValidity("");

                            // reexecuta validação
                            if (!this.validity.valid) {

                                // se inválido, coloca mensagem de erro
                                this.setCustomValidity("Coloque um Email no padrão Gmail");
                            }
                            };
                        </script>
					<br>
					<br>
					    <input class="Input4" type="password" name="senha" id="password" placeholder="Insira sua senha:" minlength="8" maxlength="10" required>
                    <br>
					<br>
                        <input type="checkbox" name="termduso" class="Concordo1" id="Concordo" value="SIM" required>
                        <label for="Concordo" class="Concordo2" id="agreement-label">Eu li e concordo com os <a href="termosdeuso.html">Termos de Uso</a></label>
                    <br>
					<br>
			        <button type="submit" class="Botão" id="Botão">Cadastrar</button>
				</form>
        </section>
        <footer class="Rodape">
                    <img class="Logo_rodape" src="Imagens/Logo ADA-PNG.png"></a>
                    <div class="Espacamento">
                        <div class="Contato"><h2>Contatos</h2></div>
                        <div id="Contatinhos">
                            <a href="https://instagram.com/ada_.tech?igshid=Zjc2ZTc4Nzk= "><div id="Alinhar_imagem"><img class="Foto_Contato" src="Imagens/instagram.png"></a>ada_.tech</div>
                            <div id="Alinhar_imagem"><img class="Foto_Contato" src="Imagens/email.png">adatcc2022@gmail.com</div>
                        </div>
                    </div>
                    <a href="http://localhost/termosdeuso.html"><button class="Termos" type="submit">Termos de Uso</button></a>
                    <a href="http://forms.gle/vroVG1DZytyFwpQU7.html"><button class="Ajuda" type="submit">Central de Ajuda</button></a>
                </footer>
                <div class="Copyright"> ©2022 Copyright - AdaTech</div>
            </body>
        </html>