<?php

include('ProtecaoAdaTech.php');

require 'conectBDAdaTech.php';

$sessionId = $_SESSION["id_usuario"];
$user = mysqli_fetch_assoc(mysqli_query($conexao, "SELECT * FROM usuario WHERE id_usuario = $sessionId"));
?>
<!DOCTYPE html>
<html lang="pt-br">

<head>
		<meta charset="UTF-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<title>AdaTech</title>
		<link rel="stylesheet" type="text/css" href="Modulos.css">
		<link href="https://fonts.googleapis.com/css2?family=Advent+Pro:wght@300&display=swap" rel="stylesheet">
		<link href="https://fonts.googleapis.com/css2?family=Poppins:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap" rel="stylesheet">
</head>
	<body>
  <header>
        <nav class="nav-bar">
            <img class="Logo-2" src="Imagens/Logo ADA-PNG-2.png">
            <div class="nav-list">
                <ul>
                    <li class="nav-item"><a href="HomePremium.php" class="nav-link">Home</a></li>
                    <li class="nav-item"><a href="ModulosPremium.php" class="nav-link">Módulos</a></li>
                    <li class="nav-item"><a href="BibliotecaPremium.php" class="nav-link">Biblioteca</a></li>
                    <li class="nav-item"><a href="PerfilPremium.php" class="nav-link">Perfil</a></li>
                </ul>
            </div>
            <div class="mobile-menu-icon">
                <button onclick="menuShow()"><img class="icon" src="Imagens/menu_white_36dp.svg" alt=""></button>
            </div>
        </nav>
        <div class="mobile-menu">
            <ul>
                <li class="nav-item"><a href="HomePremium.php" class="nav-link">Home</a></li>
                <li class="nav-item"><a href="ModulosPremium.php" class="nav-link">Módulos</a></li>
                <li class="nav-item"><a href="BibliotecaPremium.php" class="nav-link">Biblioteca</a></li>
                <li class="nav-item"><a href="PerfilPremium.php" class="nav-link">Perfil</a></li>
            </ul>
        </div>
    </header>
  <script src="Menu.js"></script>
  <br>
  <br>
		<h1> Módulos </h1>
	<br>
		<section class="Tela">
        <div class="container">
            <div class="card">
              <div class="face Algoritmo">
                <div class="content">   
                    <img src="Imagens/algoritmo.png" class="Imagens">        
                  <h3>Algoritmo</h3>
                </div>
              </div>
              <div class="face face2">
                <div class="content">
                  <p> Os algoritmos são a base para a programação universal, mas para usá-los, precisamos entender suas características e propriedades. </p>
                  <a href="algoritmo.php"><button class="Estudar1" type="submit">Estudar</button></a>
                </div>
              </div>
           </div>
		    

           <div class="card">
            <div class="face Constantes">
              <div class="content">
                <img src="Imagens/constantes.png" class="Imagens"> 
              <h3>Constantes</h3>
              </div>
            </div>
            <div class="face face2">
              <div class="content">
                <p> Na programação, alguns dados inseridos tem propriedade fixa, vem aprender um pouco mais sobre as constantes. </p>
                <a href="constantes.php"><button class="Estudar2" type="submit">Estudar</button></a>
              </div>
            </div>
         </div>
         
         
         <div class="card">
            <div class="face Variaveis">
              <div class="content">
                <img src="Imagens/variaveis.png" class="Imagens"> 
                 <h3>Variaveis</h3>
              </div>
            </div>
            <div class="face face2">
              <div class="content">
                <p> As variáveis são requisitos indispensáveis, que armazenam valores e possibilitam a execução de códigos, veja suas propriedades. </p>
                <a href="variaveis.php"><button class="Estudar3" type="submit">Estudar</button></a>
              </div>
            </div>
         </div>
        </div>

         <br><br>
         
         <div class="container">
             <div class="card">
               <div class="face Entrada_saida">
                 <div class="content"> 
                    <img src="Imagens/entradaesaida.png" class="Imagens">            
                   <h3>Entrada e Saída</h3>
                 </div>
               </div>
               <div class="face face2">
                 <div class="content">
                  <p> explicabo voluptate et hic cum ratione a. Officia delectus illum perferendis maiores 
                    quia molestias vitae fugiat aspernatur alias corporis?</p>
                   <a href="entrada.php"><button class="Estudar4" type="submit">Estudar</button></a>
                 </div>
               </div>
            </div>
            
            <div class="card">
               <div class="face Tipos_de_Dados">
                 <div class="content">
                    <img src="Imagens/dados.png" class="Imagens"> 
               <h3>Tipos de Dados</h3>
                 </div>
               </div>
               <div class="face face2">
                 <div class="content">
                  <p> explicabo voluptate et hic cum ratione a. Officia delectus illum perferendis maiores 
                    quia molestias vitae fugiat aspernatur alias corporis?</p>
                   <a href="tiposdedados.html"><button class="Estudar5" type="submit">Estudar</button></a>
                 </div>
               </div>
            </div>
            
            
            <div class="card">
               <div class="face Operadores">
                 <div class="content">
                    <img src="Imagens/operadores.png" class="Imagens"> 
                    <h3>Operadores</h3>
                 </div>
               </div>
               <div class="face face2">
                 <div class="content">
                  <p> explicabo voluptate et hic cum ratione a. Officia delectus illum perferendis maiores 
                    quia molestias vitae fugiat aspernatur alias corporis?</p>
                   <a href="operadores.html"><button class="Estudar6" type="submit">Estudar</button></a>
                 </div>
               </div>
            </div>
         </div>

            <br><br>
     
            <div class="container">
             <div class="card">
               <div class="face Funções_Matematicas">
                 <div class="content"> 
                    <img src="Imagens/funcoes.png" class="Imagens">           
                   <h3>Funções Matemáticas</h3>
                 </div>
               </div>
               <div class="face face2">
                 <div class="content">
                  <p> explicabo voluptate et hic cum ratione a. Officia delectus illum perferendis maiores 
                    quia molestias vitae fugiat aspernatur alias corporis?</p>
                   <a href="#"><button class="Estudar7" type="submit">Estudar</button></a>
                 </div>
               </div>
            </div>
            
            <div class="card">
                <div class="face Condicionais">
                  <div class="content">
                    <img src="Imagens/condicionais.png" class="Imagens"> 
                     <h3>Condicionais</h3>
                  </div>
                </div>
                <div class="face face2">
                  <div class="content">
                    <p> explicabo voluptate et hic cum ratione a. Officia delectus illum perferendis maiores 
                      quia molestias vitae fugiat aspernatur alias corporis?</p>
                    <a href="#"><button class="Estudar8" type="submit">Estudar</button></a>
                  </div>
                </div>
             </div> 
            
            
            <div class="card">
               <div class="face Expressões_Logicas">
                 <div class="content">
                    <img src="Imagens/expressoes.png" class="Imagens"> 
                    <h3>Expressões Lógicas</h3>
                 </div>
               </div>
               <div class="face face2">
                 <div class="content">
                  <p> explicabo voluptate et hic cum ratione a. Officia delectus illum perferendis maiores 
                    quia molestias vitae fugiat aspernatur alias corporis?</p>
                   <a href="#"><button class="Estudar9" type="submit">Estudar</button></a>
                 </div>
               </div>
            </div> 
        </div>
        </section>
        <footer class="Rodape">
                    <img class="Logo_rodape" src="Imagens/Logo ADA-PNG.png"></a>
                    <div class="Espacamento">
                        <div class="Contato"><h2>Contatos</h2></div>
                        <div id="Contatinhos">
                            <a href="https://instagram.com/ada_.tech?igshid=Zjc2ZTc4Nzk= "><div id="Alinhar_imagem"><img class="Foto_Contato" src="Imagens/instagram.png"></a>ada_.tech</div>
                            <div id="Alinhar_imagem"><img class="Foto_Contato" src="Imagens/email.png">adatcc2022@gmail.com</div>
                        </div>
                    </div>
                    <a href="http://localhost/termosdeuso.html"><button class="Termos" type="submit">Termos de Uso</button></a>
                    <a href="http://forms.gle/vroVG1DZytyFwpQU7.html"><button class="Ajuda" type="submit">Central de Ajuda</button></a>
                </footer>
                <div class="Copyright"> ©2022 Copyright - AdaTech</div>
            </body>
        </html>