<?php

    const MAIL_HOST     = 'smtp.mailtrap.io';
    const MAIL_USERNAME = '579e509014f291';
    const MAIL_PASSWORD = '37b7373343f0f3';
    const MAIL_PORT     = 2525;